﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EduSearch_Information_System {
    public class DocRepresentation {
        private int Id;
        private string title;
        private string author;
        private string bib;
        private string docAbstract;

        public string Title {
            get {
                return title;
            }

            set {
                title = value;
            }
        }

        public string Author {
            get {
                return author;
            }

            set {
                author = value;
            }
        }

        public string Bib {
            get {
                return bib;
            }

            set {
                bib = value;
            }
        }

        public string DocAbstract {
            get {
                return docAbstract;
            }

            set {
                docAbstract = value;
            }
        }

        public int ID {
            get {
                return Id;
            }

            set {
                Id = value;
            }
        }

        public DocRepresentation(int ID,string title, string author, string bib, string docAbstract) {
            this.Id = ID;
            this.title = title;
            this.author = author;
            this.bib = bib;
            this.docAbstract = docAbstract;
        }
       
    }
}
