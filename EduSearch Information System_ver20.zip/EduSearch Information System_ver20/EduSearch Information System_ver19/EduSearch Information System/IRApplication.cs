﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lucene.Net.Analysis; // for Analyser
using Lucene.Net.Documents; // for Documents
using Lucene.Net.Index; //for Index Writer
using Lucene.Net.Store; //for Directory
using Lucene.Net.Search; // for IndexSearcher
using Lucene.Net.QueryParsers;  // for QueryParser
using Lucene.Net.Analysis.Snowball;
using System.IO;
using System.Net.Http;
using System.Collections;
using System.Timers;

namespace EduSearch_Information_System {

    public partial class IRApplication : Form {
        public string[] searchResultList;
        public string[] TempText;
        Lucene.Net.Store.Directory luceneIndexDirectory;
        Lucene.Net.Analysis.Analyzer analyzer;
        Lucene.Net.Index.IndexWriter writer;
        Lucene.Net.Search.IndexSearcher searcher;
        Lucene.Net.QueryParsers.QueryParser parser;
        Lucene.Net.Search.Similarity newSimilarity;

        public static Lucene.Net.Util.Version VERSION = Lucene.Net.Util.Version.LUCENE_30;
        const string TITLE_FN = "Title";
        const string AUTHOR_FN = "Author";
        const string BIBLIOGRAPHIC_FN = "Bibliographic";
        const string ABSTRACT_FN = "Abstract";
        

        //create object for storing document abstracts
        Dictionary<int, DocRepresentation>documents = new Dictionary< int, DocRepresentation>();

        public IRApplication() {
            InitializeComponent();
            searchResultList = new string[1];
            TempText = new string[1400];
            analyzer = new Lucene.Net.Analysis.Standard.StandardAnalyzer(VERSION);
            newSimilarity = new NewSimilarity();

            btn_ClearQuery.Enabled = false;
            BrowseIndexButton.Enabled = false;
            CreateIndexButton.Enabled = false;
            SearchButton.Enabled = false;
            btn_SaveFile.Enabled = false;
        }

        /// <summary>
        /// Load window form
        /// </summary>
        public void Form1_Load(object sender, EventArgs e) {

        }

        /// <summary>
        /// Creates the index at a given path
        /// </summary>
        /// <param name="indexPath">The pathname to create the index</param>
        public void CreateIndex(string indexPath) {
            luceneIndexDirectory = FSDirectory.Open(indexPath);
            IndexWriter.MaxFieldLength mfl = new IndexWriter.MaxFieldLength(IndexWriter.DEFAULT_MAX_FIELD_LENGTH);
            writer = new Lucene.Net.Index.IndexWriter(luceneIndexDirectory, analyzer, true, mfl);
            writer.SetSimilarity(newSimilarity);
        }

        /// <summary>
        /// Add the text to the index
        /// </summary>
        /// <param name="text">The text to index</param>
        public void IndexText(string title, string author, string bibliographic, string documentabstract) {

            Lucene.Net.Documents.Document doc = new Document();
            

            Field titleField = new Field(TITLE_FN, title, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.WITH_POSITIONS_OFFSETS);
            Field authorField = new Field(AUTHOR_FN, author, Field.Store.NO, Field.Index.NOT_ANALYZED, Field.TermVector.WITH_POSITIONS_OFFSETS);
            Field bibliographicField = new Field(BIBLIOGRAPHIC_FN, bibliographic, Field.Store.NO, Field.Index.NOT_ANALYZED, Field.TermVector.WITH_POSITIONS_OFFSETS);
            Field fullabstractField = new Field(ABSTRACT_FN, documentabstract, Field.Store.NO, Field.Index.ANALYZED, Field.TermVector.WITH_POSITIONS_OFFSETS);

            titleField.Boost = 5;

            doc.Add(titleField);

            writer.AddDocument(doc);
        }

        /// <summary>
        /// Flushes buffer and closes the index
        /// </summary>
        public void CleanUpIndexer() {
            writer.Optimize();
            writer.Flush(true, true, true);
            writer.Dispose();
        }
        /// <summary>
        /// Initialises the searcher object
        /// </summary>
        public void CreateSearcher() {
            searcher = new IndexSearcher(luceneIndexDirectory);
            searcher.Similarity = newSimilarity;
        }

        /// <summary>
        /// Initialises the parser object
        /// </summary>
        public void CreateParser() {
            string[] fields = { TITLE_FN, ABSTRACT_FN };

            var boosts = new Dictionary<string, float> { { TITLE_FN, 5 }, { ABSTRACT_FN, 1 } };
            if (!chkBox_Preprocess.Checked) 
            {
                parser = new MultiFieldQueryParser(VERSION, fields, analyzer);
            } 
            
            else 
            {
                parser = new MultiFieldQueryParser(VERSION, fields, analyzer, boosts);
            }
        }

        /// <summary>
        /// Closes the index after searching
        /// </summary>
        public void CleanUpSearch() 
        {
            searcher.Dispose();
        }

        public TopDocs SearchIndex(string querytext) {

            querytext = querytext.ToLower();
            Query query = parser.Parse(querytext);
            MessageBox.Show("The Final QUery text being searched (with boost factor if any):\n\n"+query.ToString());
            TopDocs results = searcher.Search(query, 1400);
            totalresultLabel.Text = "Total number of result is: " + (results.TotalHits).ToString();
            int i = 0;
            int rank = 0;
            foreach (ScoreDoc scoreDoc in results.ScoreDocs) {
                rank++;
                Array.Resize<string>(ref searchResultList, i + 1);
                Lucene.Net.Documents.Document doc = searcher.Doc(scoreDoc.Doc);

                searchResultList[i] = "Q0 " + (scoreDoc.Doc + 1) + " " + rank + " " + scoreDoc.Score + " ";
                i++;
            }

            return results;
        }

        /// <summary>
        /// Pre processing information need
        /// </summary>
        //PorterStemmerAlgorithm.PorterStemmer myStemmer;
        //System.Collections.Generic.Dictionary<string, int> tokenCount;
        public string[] stopWords = { "a", "about", "above", "across", "after", "afterwards", "again", "against", "all", "almost", "alone", "along", "already", "also", "although",
                                      "always", "am", "among", "amongst", "amount", "an", "and", "another", "any", "anyhow", "anyone", "anything", "anyway", "anywhere", "are",
                                      "around", "as", "at","back","be", "been", "before", "beforehand", "behind", "being", "below", "beside", "between", "beyond", "both", "bottom", "but", "by",
                                      "can", "could", "each", "else", "empty", "enough", "etc", "even", "ever", "every", "few", "for", "from", "had", "has", "have", "he", "hence", "her", "here",
                                      "hereafter", "hereby", "herein", "hereupon", "hers", "herself", "him", "himself", "his", "how", "however", "if", "in", "into", "is", "it", "may", "me",
                                      "meanwhile", "might", "mine", "much", "must", "my", "myself", "neither", "never", "nevertheless", "next", "no", "nobody", "none", "nor", "not", "nothing", "now", "nowhere",
                                      "of", "on", "or", "other", "our", "over", "out", "per", "please", "put", "rather", "same", "should", "so", "still", "such", "than", "that", "the", "their", "then", "there",
                                      "these", "they", "this", "those", "through", "thus","to", "un", "up", "very", "via", "was", "what", "when", "where", "which", "while", "who", "whom", "whose", "why", "will",
                                      "with", "would", "yet", "you", "your"}; //list of stopwords

        /// <summary>
        /// Convert the  given text into tokens and then splits it into tokens according to whitespace and punctuation.
        /// </summary>
        /// <param name="text">Some text</param>
        /// <returns>Lower case tokens</returns>
        public string[] TokeniseString(string text) {
            char[] splitters = new char[] { ' ', '\t', '\'', '"', '-', '(', ')', ',', '’', '\n', ':', ';', '?', '.', '!' };

            if (text.Contains("\"") && text.IndexOf('\"') != text.LastIndexOf('\"')) {

                string[] stringArray = text.Split('"');
                int i = 0; int j = 0;
                string[] phrasesArray = new string[1];
                string newText = "";
                foreach (var vari in stringArray) {
                    if (i % 2 == 0)
                        newText += vari;
                    else {
                        Array.Resize(ref phrasesArray, j + 1);
                        phrasesArray[j++] = "\"" + vari + "\"^5";
                    }

                    i++;
                }


                string[] returnArray = newText.ToLower().Split(splitters, StringSplitOptions.RemoveEmptyEntries);

                int arraylength = returnArray.Length;
                int phrasesLength = phrasesArray.Length;

                Array.Resize(ref returnArray, arraylength + phrasesLength);

                for (i = 0; i < phrasesLength; i++)
                    returnArray[arraylength + i] = phrasesArray[i];

                return returnArray;//text.ToLower().Split(splitters, StringSplitOptions.RemoveEmptyEntries);
            } else
                return text.ToLower().Split(splitters, StringSplitOptions.RemoveEmptyEntries);
        }


        /// <summary>
        /// Removes stopwords from an array of tokens
        /// </summary>
        /// <param name="tokens">An array of tokens</param>
        /// <returns>The array of tokens without any stopwords</returns>
        public string[] StopWordFilter(string[] tokens) {
            int numTokens = tokens.Count();
            List<string> filteredTokens = new List<string>();
            for (int i = 0; i < numTokens; i++) {
                string token = tokens[i];
                if (!stopWords.Contains(token) && (token.Length > 2)) filteredTokens.Add(token);
            }
            return filteredTokens.ToArray<string>();
        }

        /// <summary>
        /// Stems an array of tokens
        /// </summary>
        /// <param name="tokens">An array of lowercase tokens</param>
        /// <returns>An array of stems</returns>
        //public string[] StemTokens(string[] tokens)
        //{
        //    int numTokens = tokens.Count();
        //    string[] stems = new string[numTokens];
        //    for (int i = 0; i < numTokens; i++)
        //    {
        //        stems[i] = myStemmer.stemTerm(tokens[i]);
        //    }
        //    return stems;
        //}

        /// <summary>
        /// Prints out tokens for a given text string
        /// </summary>
        /// <param name="str">a string of text</param>
        public string OutputTokens(string str) {
            System.Console.WriteLine("Orginal: \"" + str + "\"");
            string[] tokens = TokeniseString(str);
            string[] tokensnostop = this.StopWordFilter(tokens);

            Console.WriteLine("Tokens: ");
            string outputoken = "";
            foreach (string t in tokensnostop) {
                outputoken = outputoken + t + " ";
                System.Console.WriteLine(t);
            }
            Console.WriteLine(outputoken);
            return outputoken;
        }

        /// <summary>
        /// Query Expansion
        /// </summary>
        /// <param name="thesaurus"></param>
        /// <param name="queryTerm"></param>
        //async static void GetRequest(string url) {
        //    using (HttpClient client = new HttpClient()) {
        //        using (HttpResponseMessage response = await client.GetAsync(url)) {
        //            using (HttpContent content = response.Content) {
        //                string mycontent = await content.ReadAsStringAsync();
        //                string fileName = "testtesttest.txt";
        //                using (StreamWriter textWriter = new StreamWriter(fileName, true)) {
        //                    textWriter.WriteLine(mycontent);
        //                }
        //            }
        //        }
        //    }
        //}

        //public Dictionary<string, string[]> CreateThesaurus(string stem) {
        //    string http = "http://words.bighugelabs.com/api/2/10e62037f182457f5b055e09f85771af/" + stem + "/";
        //    GetRequest(http);
        //    // If error occur here, set the path to the file testtesttest.text in debug
        //    string path = @"H:\EduSearch Information System\EduSearch Information System_ver11\EduSearch Information System\bin\Debug\testtesttest.txt";
        //    string text = System.IO.File.ReadAllText(path);
        //    string[] delimiter = new string[] { "noun|syn|", "verb|syn|", "noun|ant|", "adjective|syn|", "verb|ant|" };
        //    string[] array = text.Split(delimiter, StringSplitOptions.None);
        //    Dictionary<string, string[]> thesaurus = new Dictionary<string, string[]>();
        //    thesaurus.Add(stem, array);
        //    return thesaurus;
        //}
        //public string GetExpandedQuery(Dictionary<string, string[]> thesaurus, string queryTerm) {
        //    string expandedQuery = "";
        //    if (thesaurus.ContainsKey(queryTerm)) {
        //        string[] array = thesaurus[queryTerm];
        //        foreach (string a in array) {
        //            expandedQuery += " " + a;
        //        }
        //    }
        //    return expandedQuery;
        //}

        /// <summary>
        /// Update paging footer
        /// </summary>
        public void updatePagingFooter(int numOfPage) {
            for (int i = 1; i <= numOfPage; i++) {
                cbPagingIndex.Items.Add(i);
            }
        }

        /// <summary>
        /// Outputs results to the screen
        /// </summary>
        /// <param name="results">Search results</param>
        public void DisplayResults(TopDocs results, int pagingIndex, int maxDisplay) {
            listView.Items.Clear();
            int offset = pagingIndex * maxDisplay;
            int realDisplay = Math.Min(maxDisplay, results.ScoreDocs.Length - offset);

            string[] delimiter1 = new string[] { ".I", ".T", ".A", ".B", ".W", " ." };
            int rank = offset;
            string[] delimiter2 = new string[] { " ." };
            //for (ScoreDoc scoreDoc in results.ScoreDocs)
            for (int j = offset; j < offset + realDisplay; j++) {
                ScoreDoc scoreDoc = results.ScoreDocs[j];
                rank++;
                // retrieve the document from the 'ScoreDoc' object
                Lucene.Net.Documents.Document doc = searcher.Doc(scoreDoc.Doc);
                string titleValue = doc.Get(TITLE_FN).ToString();

                DocRepresentation retrievedDoc = documents[scoreDoc.Doc];
                string authorValue = retrievedDoc.Author;
                string biblioValue = retrievedDoc.Bib;
                string abstractValue = retrievedDoc.DocAbstract;
                string[] array = abstractValue.Split(delimiter2, StringSplitOptions.None);
                ListViewItem item = new ListViewItem(rank.ToString());

                item.SubItems.Add(titleValue);
                item.SubItems.Add(authorValue);
                item.SubItems.Add(biblioValue);
                item.SubItems.Add(array[0]);
                item.SubItems.Add(abstractValue);

                listView.Items.Add(item);
            }
        }


        /******THE BELOW PART IS FOR EXECUTING TASKS*****/

        /// <summary>
        /// Browse documents directory and index path
        /// </summary>
        private void BrowseSourceButton_Click(object sender, EventArgs e) {
            SourceBrowserDialog.ShowDialog();
            SourcePathLabel.Text = SourceBrowserDialog.SelectedPath;

            int fileCount = (from file in System.IO.Directory.EnumerateFiles(SourcePathLabel.Text, "*.*", SearchOption.AllDirectories)
                             select file).Count();

            if (fileCount <1400)
            {
                MessageBox.Show("Files Missing");
                return;
            }

            lbl_temporaryText.Text = "Reading Files.";
            lbl_ToolName.Text = "Reading Files.";
            for (int i= 0;i< 1400; i++)
            {
                if (i % 200 == 0) {
                    lbl_temporaryText.Text += ".";
                    lbl_ToolName.Text += ".";
                }

                TempText[i] = System.IO.File.ReadAllText(SourcePathLabel.Text + @"\" + (i+1) + ".txt");
            }

            lbl_temporaryText.Text = "";
            lbl_ToolName.Text = "";
            BrowseIndexButton.Enabled = true;
        }

        private void BrowseIndexButton_Click(object sender, EventArgs e) {
            IndexBrowseDialog.ShowDialog();
            IndexPathLabel.Text = IndexBrowseDialog.SelectedPath;
            btn_ClearQuery.Enabled = true;
            CreateIndexButton.Enabled = true;
            SearchButton.Enabled = true;
            btn_SaveFile.Enabled = true;
        }

        /// <summary>
        /// Build index
        /// </summary>
        private void CreateIndexButton_Click(object sender, EventArgs e) {
            //GetRequest("http://words.bighugelabs.com/api/2/10e62037f182457f5b055e09f85771af/similarity&laws/");

            // Calculate time excution
            System.Diagnostics.Stopwatch watch = System.Diagnostics.Stopwatch.StartNew();

            CreateIndex(IndexPathLabel.Text);

            List<string> l = new List<string>();     

            l.AddRange(@TempText);

            string[] delimiter1 = new string[] { ".I", ".T", ".A", ".B", ".W" };
            string[] delimiter2 = new string[] { " ." };
            documents.Clear();

            foreach (string s in l) {

                string[] array = s.Split(delimiter1, StringSplitOptions.None);
                // string documentabstract = string.Join(" ", array.Skip(7));
                string[] documentabstract = array[5].Split(delimiter2, StringSplitOptions.None);
                string abs = string.Join(" .", documentabstract.Skip(1));
                IndexText(array[2], array[3], array[4], abs);//documentabstract);
                                                             // MessageBox.Show(array[1]);
                DocRepresentation docRepresentation = new DocRepresentation(int.Parse(array[1]), array[2], array[3], array[4], abs);
             //   documents[docCount] = new Dictionary<string, DocRepresentation>();
                documents.Add(int.Parse(array[1]), docRepresentation);
                    //  documents.Add(int.Parse(array[1]), docRepresentation);
                //array[1], docRepresentation);
                //IndexText(array[1], array[3], array[4], array[5]);
            }


            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            TimeExcutionLabel.Text = "Index takes " + elapsedMs.ToString() + " milisecond";

            CleanUpIndexer();
        }

        /// <summary>
        /// Process user information need
        /// </summary>
        private void InformationNeedButton_Click(object sender, EventArgs e) {

            OutputTokens(SearchBox.Text);
        }

        /// <summary>
        /// Initiate search process
        /// </summary>
        private void SearchButton_Click(object sender, EventArgs e) {

            if (SearchBox.Text == "")
                MessageBox.Show("Search Query cannot be NULL");
            else 
            {
                var watch = System.Diagnostics.Stopwatch.StartNew();

                if (!chkBox_Preprocess.Checked) {
                    txtBox_FinalQuery.Text = SearchBox.Text;
                    CreateSearcher();
                    CreateParser();
                    results = SearchIndex(SearchBox.Text);

                } else {
                    string finalQuery = OutputTokens(SearchBox.Text);
                    if (finalQuery == "")
                    {
                        MessageBox.Show("Final Query Resuts as NULL!!!");
                        return;
                    }
                    CreateSearcher();
                    CreateParser();
                    txtBox_FinalQuery.Text = finalQuery;
                    results = SearchIndex(finalQuery);
                }

                //calculating paging index
                int numOfPage = (int)Math.Ceiling((double)results.ScoreDocs.Length / (double)maxDisplay);

                DisplayResults(results, 0, maxDisplay);
                watch.Stop();
                var elapsedMs = watch.ElapsedMilliseconds;
                SearchTimeExcutionLabel.Text = "Search takes " + elapsedMs.ToString() + " milisecond";

                //update paging footer
                cbPagingIndex.Items.Clear();
                try {
                    cbPagingIndex.SelectedIndex = 1;
                } catch (Exception ex) {

                }
                for (int i = 0; i < numOfPage; i++) {
                    cbPagingIndex.Items.Add("Page " + (i + 1));
                }
            }
        }

        /// <summary>
        /// Store the result of the most recent Search Button click
        /// </summary>
        TopDocs results;
        int maxDisplay = 10;

        /// <summary>
        /// Browsing the search result
        /// </summary>
        private void cbPagingIndex_SelectedIndexChanged(object sender, EventArgs e) {
            DisplayResults(results, cbPagingIndex.SelectedIndex, maxDisplay);
        }

        /// <summary>
        /// Display full document information
        /// </summary>
        private void listView_ItemActivate(object sender, EventArgs e) {
            if (listView.SelectedItems.Count > 0) {
                ListViewItem item = listView.SelectedItems[0];
                MessageBox.Show("Title: " + item.SubItems[1].Text + "\nAuthor: " + item.SubItems[2].Text + "\nBibliography: " + item.SubItems[3].Text + "\n\nAbstract:\n" + item.SubItems[5].Text);
            }
        }

        /// <summary>
        /// Save search result to a file for evaluation
        /// </summary>
        private void btn_SaveFile_Click(object sender, EventArgs e) {


            SourceBrowserDialog.ShowDialog();
            string destination = SourceBrowserDialog.SelectedPath;


            string fileName = txtBox_FileName.Text + ".txt";
            string ID_SavedFile = txtBox_Identifier.Text;


            using (StreamWriter textWriter = new StreamWriter(destination +"\\" +fileName, true)) {
                foreach (string var in searchResultList) {
                    textWriter.Write(ID_SavedFile + " ");
                    textWriter.Write(var);
                    textWriter.WriteLine("N9535250_N8635307_N8925909_TeamIR");
                }
            }
            MessageBox.Show("Results Saved!!");
        }

        /// <summary>
        /// Clear query for new search
        /// </summary>
        private void btn_ClearQuery_Click(object sender, EventArgs e) {
            SearchBox.Text = "";
            txtBox_FinalQuery.Text = "";
            listView.Items.Clear();
            this.SearchTimeExcutionLabel.Text = "";
            this.totalresultLabel.Text = "";
        }
    }
}
