﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lucene.Net.Search;
using FieldInvertState = Lucene.Net.Index.FieldInvertState;

namespace EduSearch_Information_System
{
    public class NewSimilarity : DefaultSimilarity
    {

        /// <summary>Implemented as <c>sqrt(freq)</c>. </summary>
        public override float Tf(float freq)
        {
            //return (float)System.Math.Sqrt(freq);
            return 1;
        }

        public override float Idf(int docFreq, int numDocs)
        {
            //return (float)(System.Math.Log(numDocs / (double)(docFreq + 1)) + 1.0);
            return 1;
        }

        public override float LengthNorm(string fieldName, int numTerms)
        {
            //default similarity
            //return (float)(1.0 / System.Math.Sqrt(numTerms));

            if (fieldName.Equals("Title"))
                return (float)(0.1 * Math.Log(numTerms));
            else return LengthNorm(fieldName, numTerms);
        }

    }

}